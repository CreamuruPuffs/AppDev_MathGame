package com.example.mathgame;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    EditText answerIn;
    TextView question, scoring;
    Button submitAnswer;

    Random ra = new Random();

    int setter = 0;
    int quesNum1 = 0;
    int quesNum2 = 0;
    int score = 0;
    int rightAnswer, inputAnswer;
    String answer, playerAnswer, scorePrint;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //first question
        setter = ra.nextInt(3);
        quesNum1 = ra.nextInt(100)+1;
        quesNum2 = ra.nextInt(100)+1;

        if(setter == 0){
            answer=(quesNum1 + " + " + quesNum2);
            rightAnswer=(quesNum1 + quesNum2);
        }
        if(setter == 1){
            answer=(quesNum1 + " - " + quesNum2);
            rightAnswer=(quesNum1 - quesNum2);
        }
        if(setter == 2){
            answer=(quesNum1 + " * " + quesNum2);
            rightAnswer=(quesNum1 * quesNum2);
        }

        answerIn = findViewById(R.id.answerIn);
        question = findViewById(R.id.question);
        scoring = findViewById(R.id.scoring);
        submitAnswer = findViewById(R.id.submitAnswer);

        question.setText(answer);

    }

    //player answer
    public void answering(View view){
        playerAnswer = answerIn.getText().toString();
        inputAnswer = Integer.parseInt(playerAnswer);
        if(inputAnswer == rightAnswer){
            score ++;

            setter = ra.nextInt(3);
            quesNum1 = ra.nextInt(100)+1;
            quesNum2 = ra.nextInt(100)+1;

            if(setter == 0){
                answer=(quesNum1 + " + " + quesNum2);
                rightAnswer=(quesNum1 + quesNum2);
            }
            if(setter == 1){
                answer=(quesNum1 + " - " + quesNum2);
                rightAnswer=(quesNum1 - quesNum2);
            }
            if(setter == 2){
                answer=(quesNum1 + " * " + quesNum2);
                rightAnswer=(quesNum1 * quesNum2);
            }

            question.setText(answer);
            scoring.setText(Integer.toString(score));
            answerIn.setText("");
        }

        else{
            Intent intent = new Intent(MainActivity.this, LogInScreen.class);
            startActivity(intent);
        }

    }

}